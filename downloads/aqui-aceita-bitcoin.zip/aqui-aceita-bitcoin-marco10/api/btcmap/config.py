"""
Configurações para a API de integração com o BTC Map e OpenStreetMap.
"""

# Configurações do servidor
API_HOST = "0.0.0.0"
API_PORT = 5000
API_DEBUG = True

# Origens permitidas para CORS
ALLOWED_ORIGINS = ["*"]

# Configurações do cliente BTC Map
BTCMAP_API_URL = "https://api.btcmap.org/v2/rpc"
BTCMAP_API_KEY = ""  # Opcional se estiver usando autenticação direta com OSM

# Configurações de autenticação direta com o OpenStreetMap
OSM_CLIENT_ID = "UQIkytZ0KaVcYPzNYevoETJG3NwFhSyaeu70pHZR8GQ"
OSM_CLIENT_SECRET = "seu_segredo_do_cliente_aqui"  # Substitua pelo valor que você recebeu
OSM_REDIRECT_URI = "https://dejaljnp.manus.space"
